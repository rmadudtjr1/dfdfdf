from django.contrib import admin
from django.urls import path, re_path
from . import views

urlpatterns = [
    path("", views.index),
    path("createNewPage/", views.createNewPage),
    path('createChild/<notionId>/<url>', views.createChild),
    path('<pageNum>/', views.pageNum),
    path('guest/<user>/<pageNum>/', views.guest),
    path('save/<notionId>/', views.save),
    path('saveBody/<notionId>/', views.saveBody),
    path('sendEmail/', views.sendEmail),
    path('remove/<notionId>', views.remove),
]