from django.apps import AppConfig


class UtabConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'utab'
